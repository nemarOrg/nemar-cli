Archive built for the nemar-cli ZIP reader tests.
